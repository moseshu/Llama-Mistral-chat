#!/bin/bash
rm -rf ./.cache/huggingface/datasets
base_model=../llama/llama_weight/Llama-2-7b-chat-hf
data_dir=../llama/data/conversation-data
peft_path=../llama/sft/llama2-checkpoint7b-128dialogue/2-checkpoint-71800/adapter_model
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5 torchrun --nproc_per_node=6 --master_port=20003 finetuning.py \
       --model_name ${base_model} \
       --enable_fsdp \
       --use_peft \
       --run_validation \
       --lora_config.r 128 \
       --batch_size_training 8 \
       --lora_config.lora_alpha 256 \
       --lora_config.target_modules '[q_proj,k_proj,v_proj,o_proj,gate_proj,down_proj,up_proj]' \
       --peft_method lora \
       --fsdp_config.pure_bf16 \
       --custom_dataset.data_path ${data_dir} \
       --dataset "custom_dataset" \
       --custom_dataset.test_size 0.0001 \
       --gradient_accumulation_steps 8 \
       --lr 2e-5 \
       --batching_strategy "packing" \
       --custom_dataset.file "custom_dataset.py:get_custom_dataset" \
       --num_epochs 4 \
       --save_model \
       --custom_dataset.max_seq_length 8192 \
       --context_length 16384 \
       --dist_checkpoint_root_folder "./checkpoint" \
       --num_workers_dataloader 8 \
       --output_dir llama2-checkpoint7b-128dialogue3 \
       --use_fast_kernels \
       --peft_path ${peft_path} 
