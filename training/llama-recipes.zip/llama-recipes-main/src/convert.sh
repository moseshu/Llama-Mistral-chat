python convert_fsdp_to_hf.py \
    --fsdp_checkpoint_path  checkpoints_mistral/fine_tuned_mistral-mistral7b \
    --consolidated_model_path mixtral-checkpoint/1-epoch/HF/ \
    --HF_model_path_or_name /kefu-nas/moses/llama/llama_weight/Mixtral-8x7B-Instruct-v0.1 \

# cp /data/yafei/models/Qwen-14B-Base/*.py checkpoints_qw/hf/
# cp /data/yafei/models/Qwen-14B-Base/configuration_qwen.py checkpoints_qw/hf/
