python convert_fsdp_to_hf.py \
    --fsdp_checkpoint_path  mixtral-checkpoint/1-epoch \
    --consolidated_model_path mixtral-checkpoint/hf/ \
    --HF_model_path_or_name /kefu-nas/moses/llama/llama_weight/Mixtral-8x7B-Instruct-v0.1 \
