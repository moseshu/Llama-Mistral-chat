# export LD_LIBRARY_PATH=/data/hujunchao/miniconda/envs/py310/lib/
#Llama-3-8B-Instruct-16k-ENZH  Mistral-7B-Instruct-16k Llama-3-8B-base-v3
model_name=/kefu-nas/moses/llama/llama_weight/Llama-3-8B-base-v3
# model_name=/kefu-nas/moses/qwen/Qwen1.5-14B-Chat
data_path=/kefu-nas/moses/llama/data/traindata/tmp5
# set NCCL_DEBUG=INFO
# set NCCL_P2P_DISABLE=1
export FT_MODEL_TYPE='llama'
#torchrun --nnodes 2 --nproc_per_node 8 --rdzv-id=7777 --rdzv-backend=c10d --rdzv-endpoint=10.35.16.153
torchrun --nnodes 1 --nproc_per_node 8 \
    finetuning.py \
    --enable_fsdp \
    --low_cpu_fsdp \
    --model_name ${model_name} \
    --batch_size_training 1 \
    --dist_checkpoint_root_folder checkpoints_mistral \
    --dist_checkpoint_folder fine_tuned_mistral \
    --custom_dataset.data_path ${data_path} \
    --dataset "custom_dataset" \
    --custom_dataset.test_size 0.0001 \
    --num_epochs 3 \
    --gradient_accumulation_steps 16 \
    --fsdp_config.pure_bf16 \
    --custom_dataset.max_seq_length 32768 \
    --batching_strategy padding \
    --lr 2e-5 \
    --lora_config.r 32 \
    --lora_config.lora_alpha 64 \
    --lora_config.target_modules '[q_proj,k_proj,v_proj,o_proj,gate_proj,down_proj,up_proj]' \
    --use_peft \
    --output_dir checkpoint-llama3-32k \
    --save_model \
    --num_workers_dataloader 8 \
    --seed 1 \
    --gradient_clipping \
    --freeze_layers False \
    --fsdp_config.fsdp_cpu_offload False \
    --num_freeze_layers 40 \
    --freeze_strategy 1
