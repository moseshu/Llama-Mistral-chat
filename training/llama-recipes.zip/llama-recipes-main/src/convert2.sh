python convert_fsdp_to_hf.py \
    --fsdp_checkpoint_path  checkpoints_qw/fine_tuned_qw2-/data/yafei/models/Qwen-72B \
    --consolidated_model_path checkpoints_qw/hf2/ \
    --HF_model_path_or_name /data/yafei/models/Qwen-72B \

cp /data/yafei/models/Qwen-14B-Base/*.py checkpoints_qw/hf2/
cp /data/yafei/models/Qwen-14B-Base/configuration_qwen.py checkpoints_qw/hf2/
