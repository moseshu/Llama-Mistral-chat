from llama_recipes.inference.checkpoint_converter_fsdp_hf import main
import fire

if __name__ == "__main__":
    fire.Fire(main)