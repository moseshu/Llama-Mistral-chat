# export LD_LIBRARY_PATH=/data/hujunchao/miniconda/envs/py310/lib/

torchrun --nnodes 1 --nproc_per_node 8 \
    finetuning.py \
    --enable_fsdp \
    --low_cpu_fsdp \
    --model_name /data/yafei/models/Qwen-72B \
    --batch_size_training 1 \
    --dist_checkpoint_root_folder checkpoints_qw \
    --dist_checkpoint_folder fine_tuned_qw2 \
    --dataset /data/yafei/git_root/llama-recipes-main/data/data_dialogue2nlp_abs/total_train_nlp_abs_to_record_grouped_abs.xlsx \
    --num_epochs 5 \
    --gradient_accumulation_steps 8 \
    --fsdp_config.pure_bf16 \
    --batching_strategy padding \
    --lr 2e-5 \
    --seed 123456 \
    --gradient_clipping \
    --freeze_layers \
    --num_freeze_layers 35 \
    --freeze_strategy 1
