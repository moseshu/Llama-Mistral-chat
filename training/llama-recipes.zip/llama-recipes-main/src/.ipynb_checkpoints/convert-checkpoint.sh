python convert_fsdp_to_hf.py \
    --fsdp_checkpoint_path  checkpoints_mistral/fine_tuned_mistral-mistral7b \
    --consolidated_model_path checkpoints_mistral/hf/ \
    --HF_model_path_or_name /root/moses/llama/llama_weight/Mistral-7B-Instruct-v0.2 \

# cp /data/yafei/models/Qwen-14B-Base/*.py checkpoints_qw/hf/
# cp /data/yafei/models/Qwen-14B-Base/configuration_qwen.py checkpoints_qw/hf/
